package com.example.mbhs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MbhstvApplication {

	public static void main(String[] args) {
		SpringApplication.run(MbhstvApplication.class, args);
	}

}
